import React from 'react';
//import SeasonDisplay from './SeasonDisplay';
//import Spinner from './Spinner';
import Uploadfile from './uploadfile';

class App extends React.Component {

 
  render() {
    return <Uploadfile/>;
   /*  if(this.state.lat && !this.state.error){
      return <SeasonDisplay lat={this.state.lat} month={new Date().getMonth()}/>
    }
    if(!this.state.lat && this.state.error){
      return <h3>Error: {this.state.error}</h3>;
    } */
   // return <Spinner />;
  }
}

export default App;
