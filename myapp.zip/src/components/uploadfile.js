import React from 'react';
import axios from 'axios';
class UploadFile extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
          value: 'coconut',
          course:'',
          subtopic:'',
          marks:'',
          time:'',
          fileupload:'',
          submitted: false,
          selectedFile: null,
          loaded: 0,


    };
  
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) {
      this.setState({ [event.target.name]: event.target.value
     
    });
    }
  
    handleSubmit(event) {
   
     console.log(this.state);
        
      const {  marks,time,course,subtopic,selectedFile } = this.state;
      this.setState({ submitted: true });

      const data = { 'marks': marks, 'time': time ,'course':course,'subtopic':subtopic,'selectedFile':selectedFile};

     console.log(data);
      event.preventDefault();

    }

  handleselectedFile = event => {
    this.setState({
      selectedFile: event.target.files[0],
      loaded: 0,
    })
  }
  handleUpload = () => {
    const data = new FormData()
    data.append('file', this.state.selectedFile, this.state.selectedFile.name)
    
    // rest controller---->
    axios.post(`http://localhost:8080/data/fileUpload`, data, {
        onUploadProgress: ProgressEvent => {
          this.setState({
            loaded: (ProgressEvent.loaded / ProgressEvent.total*100),
          })
        },
      })
      .then(res => {
        console.log(res.statusText)
      })

  }
    render() {
      return (
       
        <form onSubmit={this.handleSubmit}>
         <table border='2'> <tr> 
          <label>
          Course:
            <select name="course"  onChange={this.handleChange}>
              <option value="Java">Java</option>
              <option value="React">React</option>
              <option value="Angular">Angular</option>
            </select>
          </label>
        
          </tr>&nbsp;&nbsp;
          <tr>&nbsp;&nbsp; 
          <label> 
          
         Subtopics:
            <select  name="subtopic"  onChange={this.handleChange}>
              <option value="subtopic1">subtopic1</option>
              <option value="subtopic2">subtopic2</option>
              <option value="subtopic13">subtopic13</option>
            </select>
          </label>
          <label>
          </label>
          </tr>&nbsp;&nbsp;
          <tr>
          marks  <input type="number" name="marks"  value={this.state.marks}
                                                onChange={this.handleChange}/> </tr>&nbsp;&nbsp;
         <tr>                                      
       <label>Time</label>
       <input type="number" name="time"  value={this.state.time}
                                                onChange={this.handleChange}/>
                                                </tr> &nbsp;&nbsp;
          <tr>                                      
       <label>UploadFile</label>
        {/* <input type="file" name="fileupload"/>  */}
        <input type="file" onChange={this.handleselectedFile}/>
        <button onClick={this.handleUpload}>Upload</button>
        <div> {Math.round(this.state.loaded,2) } %</div>
        </tr>
          <input type="submit" value="Submit" />
          </table>
        </form>
       
      );
    }
  }
  export default UploadFile;